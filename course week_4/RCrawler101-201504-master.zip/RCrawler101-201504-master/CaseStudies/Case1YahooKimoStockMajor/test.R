rm(list=ls(all.names = TRUE))
source("packIntoFunction.R")

View(getStockMajorData(2330))
View(getStockMajorData(2454))
