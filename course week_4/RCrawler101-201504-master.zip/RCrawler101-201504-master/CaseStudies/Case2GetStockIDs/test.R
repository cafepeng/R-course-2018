
source("packIntoFunction.R")

getMarketIDS("sii")
getMarketIDS("otc")
getMarketIDS("rotc")
