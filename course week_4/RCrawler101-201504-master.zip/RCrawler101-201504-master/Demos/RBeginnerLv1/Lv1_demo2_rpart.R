# install.packages("rpart")
library(rpart)

# play example directly!
example(rpart)

# view data
head(kyphosis)
tail(kyphosis)
View(kyphosis)
summary(kyphosis)

